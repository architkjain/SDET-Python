# Required imports
import time
from selenium import webdriver
from selenium.webdriver import ActionChains

# Webdriver for Chrome browser
driver = webdriver.Chrome(executable_path="D:\\chromedriver.exe")
driver.implicitly_wait(15)
# ----------------------------------------------------------------------------------------------------------------------

# Launch Xornet page (1)

driver.get("https://xornet.xoriant.com/")
driver.maximize_window()
print()
print("I am on the login page.")
# ----------------------------------------------------------------------------------------------------------------------

# Enter credentials on the Login page to launch Xornet page (2)

driver.find_element_by_id("userNameInput").send_keys("")
driver.find_element_by_id("passwordInput").send_keys("")
driver.find_element_by_id("submitButton").click()
# time.sleep(3)

# Close the image pop-up after Xornet page is launched
driver.find_element_by_xpath("//span[@class='block-views-block-pop-up-block-block-1-modal-close spb_close']").click()

print()
print("Xornet URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm logged into Xornet")
# ----------------------------------------------------------------------------------------------------------------------

# Navigate to Apps and Tools --> Hyfi. Switch to Hyfi tab, login, logout and close the tab (4)

# Get current window handle
current_tab_handle = driver.current_window_handle
print()
print("First tab handle :", current_tab_handle)

# Mouse Hover on Apps and Tools
apps_tools = driver.find_element_by_xpath("//a[text()='Apps and Tools']")
action = ActionChains(driver)
action.move_to_element(apps_tools).perform()
time.sleep(3)

# Click on Hyfi link
driver.find_element_by_link_text("HyFi").click()
time.sleep(5)

# Get all tab/window handles
all_tab_handles = driver.window_handles
if driver.current_window_handle == current_tab_handle:
    driver.switch_to.window(all_tab_handles[1])

print("Second tab handle :", all_tab_handles[1])
print()
print("HyFi Tab URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm on the HyFi login page.")

# Click on Sign-in button on the right side
driver.find_element_by_xpath("//button[@class='btn log-btn']").click()
time.sleep(3)
driver.find_element_by_xpath("//button[@class='btn btn-primary btn-ok']").click()

# Verify username to confirm successful login
user_name = driver.find_element_by_xpath(
        "//button[@class='mat-focus-indicator username mat-icon-button mat-button-base mat-button-disabled "
        "ng-star-inserted']//span[@class='mat-button-wrapper']").text
if user_name == 'account_circle Suvacha Pitre':
    print("User is logged in successfully.")
else:
    print("User not logged in successfully.")

# Pause to show the logged in screen
time.sleep(3)

# Sign out and close window
# sign_out = driver.find_element_by_xpath(
#     "//button[@class='mat-focus-indicator logout-button logout-button-desktop mat-icon-button mat-button-base "
#     "cdk-focused cdk-mouse-focused']//span[@class='mat-button-wrapper']")

# (above xpath is not working hence had to use below format for sign out element)
sign_out = driver.find_element_by_xpath("//app-header/mat-toolbar[1]/button[1]/span[1]")
sign_out.click()
print("User is logged out successfully.")

# Pause to show the logged off screen
time.sleep(3)

# Close current tab
driver.close()
# ----------------------------------------------------------------------------------------------------------------------
