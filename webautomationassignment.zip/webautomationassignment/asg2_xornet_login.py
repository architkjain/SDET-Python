# Required imports
import time
from selenium import webdriver

# Webdriver for Chrome browser
driver = webdriver.Chrome(executable_path="D:\\chromedriver.exe")
driver.implicitly_wait(15)
# ----------------------------------------------------------------------------------------------------------------------

# Launch Xornet page (1)

driver.get("https://xornet.xoriant.com/")
time.sleep(3)
driver.maximize_window()
print()
print("I am on the login page.")
# ----------------------------------------------------------------------------------------------------------------------

# Enter credentials on the Login page to launch Xornet page (2)

driver.find_element_by_id("userNameInput").send_keys("")
driver.find_element_by_id("passwordInput").send_keys("")
driver.find_element_by_id("submitButton").click()
time.sleep(3)

# Close the image pop-up after Xornet page is launched
driver.find_element_by_xpath("//span[@class='block-views-block-pop-up-block-block-1-modal-close spb_close']").click()

print()
print("Xornet URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm logged into Xornet")
# ----------------------------------------------------------------------------------------------------------------------
