# Required imports
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.support.select import Select
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

# Webdriver for Chrome browser
driver = webdriver.Chrome(executable_path="D:\\chromedriver.exe")
driver.implicitly_wait(15)
# ----------------------------------------------------------------------------------------------------------------------

# Launch Xornet page (1)

driver.get("https://xornet.xoriant.com/")
driver.maximize_window()
print()
print("I am on the login page.")
# ----------------------------------------------------------------------------------------------------------------------

# Enter credentials on the Login page to launch Xornet page (2)

driver.find_element_by_id("userNameInput").send_keys("")
driver.find_element_by_id("passwordInput").send_keys("")
driver.find_element_by_id("submitButton").click()
# time.sleep(3)

# Close the image pop-up after Xornet page is launched
driver.find_element_by_xpath("//span[@class='block-views-block-pop-up-block-block-1-modal-close spb_close']").click()

print()
print("Xornet URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm logged into Xornet")
# ----------------------------------------------------------------------------------------------------------------------

# Navigate to Office Information --> Contacts --> Contacts Page
# and Fetch information from Contacts page as per applied filters (5)

action = ActionChains(driver)

# Mouse Hover on Office Location
office_location = driver.find_element_by_xpath("//a[text()='Office Information']")
action.move_to_element(office_location).perform()
time.sleep(3)

# Mouse Hover on Contacts
contacts = driver.find_element_by_xpath("//a[text()='Contacts']")
action.move_to_element(contacts).perform()
time.sleep(3)

# Click on Contacts Page
driver.find_element_by_link_text("Contacts Page").click()
print()
print("Contacts Page URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm on the Contacts page.")

# Click on filter icon
driver.find_element_by_xpath("//div[@class='desktop_icon emp_filter tooltips']//img").click()

# Enter name as "Girish" in Name text box
driver.find_element_by_id("edit-name-filter").send_keys("Girish")

# Select "Sunnyvale" from location drop-down
location = Select(driver.find_element_by_id("location_filter"))
location.select_by_visible_text("Sunnyvale")
time.sleep(3)

# Click on filter button
driver.find_element_by_id("employee_submit_button").click()

# From the results fetch department and email id of Girish Gaitonde
name = driver.find_element_by_xpath("//div[contains(text(),'Girish Gaitonde')]")
department = driver.find_element_by_css_selector("tr[class='emp_result_row odd'] td[class='emp_dept']")
email_id = driver.find_element_by_css_selector("tr[class='emp_result_row odd'] td[class='emp_email']")
print()
print("Results are filtered for name - Girish Gaitone for Sunnyvale location.")
print("Name : ", name.text)
print("Department :", department.text)
print("Email id :", email_id.text)
# ----------------------------------------------------------------------------------------------------------------------
