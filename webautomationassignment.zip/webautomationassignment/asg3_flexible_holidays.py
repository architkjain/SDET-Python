# Required imports
import time
from selenium import webdriver
from selenium.webdriver import ActionChains

# Webdriver for Chrome browser
driver = webdriver.Chrome(executable_path="D:\\chromedriver.exe")
driver.implicitly_wait(15)
# ----------------------------------------------------------------------------------------------------------------------

# Launch Xornet page (1)

driver.get("https://xornet.xoriant.com/")
driver.maximize_window()
print()
print("I am on the login page.")
# ----------------------------------------------------------------------------------------------------------------------

# Enter credentials on the Login page to launch Xornet page (2)

driver.find_element_by_id("userNameInput").send_keys("")
driver.find_element_by_id("passwordInput").send_keys("")
driver.find_element_by_id("submitButton").click()
# time.sleep(3)

# Close the image pop-up after Xornet page is launched
driver.find_element_by_xpath("//span[@class='block-views-block-pop-up-block-block-1-modal-close spb_close']").click()

print()
print("Xornet URL :", driver.current_url)
print("Page Title :", driver.title)
print("I'm logged into Xornet")
# ----------------------------------------------------------------------------------------------------------------------

# Navigate to Office Information --> Holiday List page and fetch location wise "Flexible" Holidays (3)

# Mouse Hover on Office Location
office_location = driver.find_element_by_xpath("//a[text()='Office Information']")
action = ActionChains(driver)
action.move_to_element(office_location).perform()
time.sleep(3)

# Click on Holiday List
driver.find_element_by_link_text("Holiday List").click()
print()
print("Holiday List Page URL :", driver.current_url)
print("Page Title :", driver.title)


# Function to accept location and holiday type
def check_location_holiday(location, holiday_type):
    if location == "Pune" and holiday_type == "Flexible Holiday":
        show_flexible_holidays()
    elif location == "Bangalore" and holiday_type == "Flexible Holiday":
        driver.find_element_by_xpath("//a[text()='Bangalore']").click()
        show_flexible_holidays()
    elif location == "Chennai" and holiday_type == "Flexible Holiday":
        driver.find_element_by_xpath("//a[text()='Chennai']").click()
        show_flexible_holidays()
    elif location == "Gurgaon" and holiday_type == "Flexible Holiday":
        driver.find_element_by_xpath("//a[text()='Gurgaon']").click()
        show_flexible_holidays()
    elif location == "Hyderabad" and holiday_type == "Flexible Holiday":
        driver.find_element_by_xpath("//a[text()='Hyderabad']").click()
        show_flexible_holidays()
    elif location == "Mumbai" and holiday_type == "Flexible Holiday":
        driver.find_element_by_xpath("//a[text()='Mumbai']").click()
        show_flexible_holidays()
    elif location == "United Kingdom" or location == "United States":
        print("Flexible Holidays not applicable.")
    else:
        print("Invalid location/holiday type.")


# Function to display the flexible holidays for the given location
def show_flexible_holidays():
    # locations = ["bangalore", "chennai", "gurgaon", "hyderabad", "mumbai", "pune", "united-kingdom", "united-states"]
    #
    # flexible_holidays = driver.find_element_by_xpath("//a[text()='Flexible Holiday']")
    # location = driver.find_element_by_id("pune")
    # for flexible_holdiday in flexible_holidays:
    print("Incomplete Assignment")


# Function calls to test various scenarios
check_location_holiday("Pune", "Flexible Holiday")
check_location_holiday("Mumbai", "Flexible Holiday")
check_location_holiday("Chennai", "Other")
check_location_holiday("Surat", "Flexible Holiday")
check_location_holiday("United States", "Flexible Holiday")
# ----------------------------------------------------------------------------------------------------------------------
