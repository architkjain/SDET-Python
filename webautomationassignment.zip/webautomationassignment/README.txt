README
===========================================================================
1. Assignments are named starting with asg followed with the number given in the assignment sheet.
2. There is new file for every point and has duplicate code as required for that question.
3. As points 5,6,7 are to be done in a sequence hence asg6 file has code for asg5 and asg7 has code for both asg5 and asg6. Similarly asg1 and asg2 is common for all (xornet page launch and login)
4. Point 3 assignment is incomplete in asg3 file. Also Point 6 assignment is incomplete in asg6 file (results are not printed).
5. Code is written in simple flow without any classes.
6. Credentials for Xornet login have been removed and are required to be put in every file before running. Chrome webdriver path is given as "D:\\chromedriver.exe"
7. For point 4 for user login is successful is to be checked, hence in the code it is checked with my username - 'account_circle Suvacha Pitre' (should be replaced with the name of the logged in user).

