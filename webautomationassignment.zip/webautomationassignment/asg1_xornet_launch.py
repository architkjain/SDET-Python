# Required imports
from selenium import webdriver

# Webdriver for Chrome browser
driver = webdriver.Chrome(executable_path="D:\\chromedriver.exe")
# ----------------------------------------------------------------------------------------------------------------------

# Launch Xornet page (1)

driver.get("https://xornet.xoriant.com/")
driver.maximize_window()
print()
print("I am on the login page.")
# ----------------------------------------------------------------------------------------------------------------------
