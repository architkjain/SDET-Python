import requests
import json

host_url = "https://reqres.in"

# Assignment 1
resp_code = requests.get(host_url+"/api/users?page=1")
print(resp_code)

response_result = (json.dumps(resp_code.json(), indent=6))
print(response_result)

# Assignment 2

Query_parameter = {	"name": "AutoTestUser",	"job": "testing"}
resp_code1 = requests.post(host_url+"/api/users", data=Query_parameter)
print(resp_code1)

response_result1 = (json.dumps(resp_code1.json()))
print(response_result1)

# Assignment3

resp_code2 = requests.get(host_url+"/api/users/23")
print(resp_code2)

# Assignment 4

resp_code3 = requests.get(host_url+"/api/unknown")
print(resp_code3)
response_result3 = (json.dumps(resp_code3.json()))
print(response_result3)

# Assignment5

Query_parameter = {"email": "peter@klaven" }

resp_code4 = requests.post(host_url+"/api/login", data=Query_parameter)
print(resp_code4)

response_result4 = (json.dumps(resp_code4.json()))
print(response_result4)